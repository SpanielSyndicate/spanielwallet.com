// Spaniel Wallet — extension background service worker (MV3).
//
// Responsibilities:
//   1. Hold the unlocked vault state in memory (this script's globals).
//      MV3 service workers can be suspended at any time — when they
//      resume, all globals are blank, which auto-locks the wallet.
//   2. Track per-origin connection approvals.
//   3. Route messages between content-script.js and popup.js.
//   4. Sign messages / transactions IN this script using the
//      in-memory seed. Popups display approval UI only — the popup
//      never sees private key material.
//   5. Auto-lock after idle.

import { ed25519 } from './vendor/noble.mjs';

const STATE = {
  // Unlocked vault state. `signers` is a Map<pubkeyBase58, Uint8Array(32)>
  // of seed bytes.
  unlocked: null, // { activePubkey, signers, unlockedAt }
  pendingRequests: new Map(),
  connections: new Map(), // origin → { pubkey, approvedAt }
  popupWindowId: null
};

const IDLE_LOCK_SECONDS = 5 * 60;
let idleLockTimer = null;

function scheduleIdleLock() {
  clearTimeout(idleLockTimer);
  idleLockTimer = setTimeout(() => {
    if (STATE.unlocked) lockNow();
  }, IDLE_LOCK_SECONDS * 1000);
}

function bumpActivity() {
  if (STATE.unlocked) scheduleIdleLock();
}

function lockNow() {
  if (STATE.unlocked?.signers) {
    for (const [, seed] of STATE.unlocked.signers) {
      if (seed instanceof Uint8Array) seed.fill(0);
    }
  }
  STATE.unlocked = null;
  STATE.connections.clear();
  for (const [, req] of STATE.pendingRequests) {
    try { req.reject(mkErr('WALLET_LOCKED', 'wallet locked')); } catch {}
  }
  STATE.pendingRequests.clear();
  notifyPopup({ type: 'state', unlocked: false });
}

// ─── popup window management ───────────────────────────────────────

const POPUP_WIDTH = 400;
const POPUP_HEIGHT = 600;

async function openApprovalPopup({ kind, requestId }) {
  const url = chrome.runtime.getURL(
    `popup.html?request=${encodeURIComponent(requestId)}&kind=${encodeURIComponent(kind)}`
  );
  return new Promise((resolve) => {
    chrome.windows.create({
      url,
      type: 'popup',
      width: POPUP_WIDTH,
      height: POPUP_HEIGHT,
      focused: true
    }, (win) => {
      STATE.popupWindowId = win?.id ?? null;
      resolve(win);
    });
  });
}

function notifyPopup(message) {
  try {
    chrome.runtime.sendMessage(
      { source: 'spaniel-wallet:bg', ...message },
      () => void chrome.runtime.lastError
    );
  } catch {}
}

// ─── IPC: content-script → background ──────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg !== 'object') return;
  if (msg.source === 'spaniel-wallet:cs') {
    handleContentScriptMessage(msg, sender).then(sendResponse, (err) => {
      sendResponse({ error: { code: err?.code || 'INTERNAL', message: err?.message || String(err) } });
    });
    return true;
  }
  if (msg.source === 'spaniel-wallet:popup') {
    handlePopupMessage(msg, sender).then(sendResponse, (err) => {
      sendResponse({ error: { code: err?.code || 'INTERNAL', message: err?.message || String(err) } });
    });
    return true;
  }
});

async function handleContentScriptMessage(msg, sender) {
  bumpActivity();
  const origin = (() => {
    try { return sender?.origin || new URL(sender?.url || '').origin; } catch { return null; }
  })();
  if (!origin) throw mkErr('NO_ORIGIN', 'request missing origin');

  switch (msg.kind) {
    case 'connect':
      return queueApproval({ tabId: sender?.tab?.id ?? null, origin, kind: 'connect', payload: msg.payload || {} });
    case 'disconnect':
      STATE.connections.delete(origin);
      return { ok: true };
    case 'getConnection': {
      const c = STATE.connections.get(origin);
      return { connected: !!c, pubkey: c?.pubkey || null };
    }
    case 'signMessage':
      ensureConnected(origin);
      return queueApproval({ tabId: sender?.tab?.id ?? null, origin, kind: 'signMessage', payload: msg.payload || {} });
    case 'signTransaction':
      ensureConnected(origin);
      return queueApproval({ tabId: sender?.tab?.id ?? null, origin, kind: 'signTransaction', payload: msg.payload || {} });
    case 'signAndSendTransaction':
      ensureConnected(origin);
      // Sign-and-send isn't supported in v0.1 (we have no RPC binding
      // in the extension; the dApp's own RPC is the right place to
      // broadcast). Surface a clear error.
      throw mkErr('UNSUPPORTED', 'signAndSendTransaction not supported yet; use signTransaction + send via your RPC');
    default:
      throw mkErr('UNSUPPORTED', `unsupported request kind: ${msg.kind}`);
  }
}

function ensureConnected(origin) {
  if (!STATE.connections.has(origin)) {
    throw mkErr('NOT_CONNECTED', `origin not connected: ${origin}`);
  }
}

function queueApproval({ tabId, origin, kind, payload }) {
  const requestId = `req-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
  return new Promise((resolve, reject) => {
    STATE.pendingRequests.set(requestId, {
      tabId, origin, kind, payload, resolve, reject, createdAt: Date.now()
    });
    notifyPopup({ type: 'newRequest', requestId, origin, kind });
    openApprovalPopup({ kind, requestId });
  });
}

async function handlePopupMessage(msg /*, sender */) {
  bumpActivity();
  switch (msg.kind) {
    case 'getPendingRequest': {
      const req = STATE.pendingRequests.get(msg.requestId);
      if (!req) return { error: { code: 'NOT_FOUND', message: 'no such pending request' } };
      return {
        requestId: msg.requestId,
        origin: req.origin,
        kind: req.kind,
        payload: req.payload,
        createdAt: req.createdAt
      };
    }
    case 'getConnections':
      return {
        connections: [...STATE.connections.entries()].map(([origin, v]) => ({ origin, ...v }))
      };
    case 'getUnlockedState':
      return {
        unlocked: !!STATE.unlocked,
        activePubkey: STATE.unlocked?.activePubkey || null
      };
    case 'setUnlocked': {
      // Popup hands us the seed bytes after a successful passphrase
      // entry. We keep the 32-byte seed (not the 64-byte secretKey)
      // because noble's ed25519.sign takes the seed.
      // payload: { activePubkey, signers: [{ pubkey, seed: number[] }] }
      const signers = new Map();
      for (const s of msg.payload?.signers || []) {
        if (!s?.pubkey || !Array.isArray(s?.seed) || s.seed.length !== 32) continue;
        signers.set(s.pubkey, Uint8Array.from(s.seed));
      }
      if (signers.size === 0) throw mkErr('BAD_UNLOCK', 'no signers provided');
      STATE.unlocked = {
        activePubkey: msg.payload?.activePubkey || [...signers.keys()][0],
        signers,
        unlockedAt: Date.now()
      };
      scheduleIdleLock();
      notifyPopup({ type: 'state', unlocked: true, activePubkey: STATE.unlocked.activePubkey });
      return { ok: true };
    }
    case 'lock':
      lockNow();
      return { ok: true };
    case 'approveConnect': {
      const req = STATE.pendingRequests.get(msg.requestId);
      if (!req) return { error: { code: 'NOT_FOUND', message: 'no such pending request' } };
      if (!STATE.unlocked) {
        try { req.reject(mkErr('WALLET_LOCKED', 'wallet locked')); } catch {}
        STATE.pendingRequests.delete(msg.requestId);
        return { error: { code: 'WALLET_LOCKED', message: 'wallet locked' } };
      }
      STATE.connections.set(req.origin, {
        pubkey: STATE.unlocked.activePubkey,
        approvedAt: Date.now()
      });
      try { req.resolve({ pubkey: STATE.unlocked.activePubkey }); } catch {}
      STATE.pendingRequests.delete(msg.requestId);
      return { ok: true };
    }
    case 'approveSignMessage': {
      const req = STATE.pendingRequests.get(msg.requestId);
      if (!req) return { error: { code: 'NOT_FOUND', message: 'no such pending request' } };
      if (!STATE.unlocked) {
        try { req.reject(mkErr('WALLET_LOCKED', 'wallet locked')); } catch {}
        STATE.pendingRequests.delete(msg.requestId);
        return { error: { code: 'WALLET_LOCKED', message: 'wallet locked' } };
      }
      try {
        const pubkey = req.payload?.accountAddress || STATE.unlocked.activePubkey;
        const seed = STATE.unlocked.signers.get(pubkey);
        if (!seed) throw mkErr('NO_SIGNER', `no signer for ${pubkey}`);
        const messageBytes = Uint8Array.from(req.payload?.message || []);
        const sig = ed25519.sign(messageBytes, seed);
        req.resolve({ signature: Array.from(sig) });
        STATE.pendingRequests.delete(msg.requestId);
        return { ok: true };
      } catch (err) {
        req.reject(err);
        STATE.pendingRequests.delete(msg.requestId);
        throw err;
      }
    }
    case 'approveSignTransaction': {
      const req = STATE.pendingRequests.get(msg.requestId);
      if (!req) return { error: { code: 'NOT_FOUND', message: 'no such pending request' } };
      if (!STATE.unlocked) {
        try { req.reject(mkErr('WALLET_LOCKED', 'wallet locked')); } catch {}
        STATE.pendingRequests.delete(msg.requestId);
        return { error: { code: 'WALLET_LOCKED', message: 'wallet locked' } };
      }
      try {
        const pubkey = req.payload?.accountAddress || STATE.unlocked.activePubkey;
        const seed = STATE.unlocked.signers.get(pubkey);
        if (!seed) throw mkErr('NO_SIGNER', `no signer for ${pubkey}`);
        const inBytes = Uint8Array.from(req.payload?.transaction || []);
        const signed = signTransactionInPlace(inBytes, seed, pubkey);
        req.resolve({ signedTransaction: Array.from(signed) });
        STATE.pendingRequests.delete(msg.requestId);
        return { ok: true };
      } catch (err) {
        req.reject(err);
        STATE.pendingRequests.delete(msg.requestId);
        throw err;
      }
    }
    case 'rejectRequest': {
      const req = STATE.pendingRequests.get(msg.requestId);
      if (!req) return { ok: true };
      try { req.reject(mkErr('USER_REJECTED', 'user rejected request')); } catch {}
      STATE.pendingRequests.delete(msg.requestId);
      return { ok: true };
    }
    case 'previewSignTransaction': {
      // Read-only preview for the approval UI. Returns the parsed
      // structure so the popup can show {programIds, accountKeys,
      // numInstructions, etc.} without trusting the dApp's framing.
      const inBytes = Uint8Array.from(msg.payload?.transaction || []);
      try {
        return { preview: parseTransaction(inBytes) };
      } catch (err) {
        return { error: { code: 'PARSE_FAILED', message: err?.message || String(err) } };
      }
    }
    default:
      throw mkErr('UNSUPPORTED', `unsupported popup kind: ${msg.kind}`);
  }
}

function mkErr(code, message) {
  const e = new Error(message);
  e.code = code;
  return e;
}

// ─── transaction signing primitives ────────────────────────────────

function shortVecDecode(bytes, offset = 0) {
  let value = 0;
  let length = 0;
  for (let i = 0; i < 3; i++) {
    const b = bytes[offset + i];
    if (b === undefined) throw new Error('short_vec: truncated');
    value |= (b & 0x7f) << (7 * i);
    length = i + 1;
    if ((b & 0x80) === 0) return { value, length };
  }
  return { value, length };
}

function arrayEqual(a, b) {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
  return true;
}

const BASE58_ALPHABET = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
const BASE58_MAP = (() => {
  const m = new Int8Array(128).fill(-1);
  for (let i = 0; i < BASE58_ALPHABET.length; i++) m[BASE58_ALPHABET.charCodeAt(i)] = i;
  return m;
})();
function base58Decode(s) {
  if (!s) return new Uint8Array(0);
  let zeros = 0;
  while (zeros < s.length && s[zeros] === '1') zeros++;
  let n = 0n;
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    const d = c < 128 ? BASE58_MAP[c] : -1;
    if (d < 0) throw new Error('invalid base58');
    n = n * 58n + BigInt(d);
  }
  const out = [];
  while (n > 0n) {
    out.push(Number(n & 0xffn));
    n >>= 8n;
  }
  out.reverse();
  const b = new Uint8Array(zeros + out.length);
  for (let i = 0; i < out.length; i++) b[zeros + i] = out[i];
  return b;
}
function base58Encode(bytes) {
  if (!bytes || bytes.length === 0) return '';
  let zeros = 0;
  while (zeros < bytes.length && bytes[zeros] === 0) zeros++;
  let n = 0n;
  for (let i = 0; i < bytes.length; i++) n = n * 256n + BigInt(bytes[i]);
  let out = '';
  while (n > 0n) {
    out = BASE58_ALPHABET[Number(n % 58n)] + out;
    n /= 58n;
  }
  return '1'.repeat(zeros) + out;
}

/**
 * Parse a serialized Solana transaction (legacy or v0) into a struct
 * useful for the approval UI. Throws on malformed input.
 */
function parseTransaction(txBytes) {
  if (!(txBytes instanceof Uint8Array)) throw new Error('expected Uint8Array');
  let off = 0;
  const { value: sigCount, length: sigCountLen } = shortVecDecode(txBytes, off);
  off += sigCountLen;
  if (txBytes.length < off + sigCount * 64) throw new Error('tx: signature slots truncated');
  const signatures = [];
  for (let i = 0; i < sigCount; i++) {
    signatures.push(txBytes.slice(off + i * 64, off + (i + 1) * 64));
  }
  off += sigCount * 64;
  const messageOffset = off;
  const messageBytes = txBytes.slice(messageOffset);
  let mOff = 0;
  let isV0 = false;
  if (messageBytes[0] >= 0x80) {
    isV0 = (messageBytes[0] & 0x7f) === 0;
    mOff = 1;
  }
  const numRequiredSignatures = messageBytes[mOff];
  const numReadonlySignedAccounts = messageBytes[mOff + 1];
  const numReadonlyUnsignedAccounts = messageBytes[mOff + 2];
  mOff += 3;
  const { value: accountCount, length: accountCountLen } = shortVecDecode(messageBytes, mOff);
  mOff += accountCountLen;
  if (messageBytes.length < mOff + accountCount * 32 + 32) throw new Error('tx: accounts truncated');
  const accountKeys = [];
  for (let i = 0; i < accountCount; i++) {
    accountKeys.push(messageBytes.slice(mOff, mOff + 32));
    mOff += 32;
  }
  const recentBlockhash = messageBytes.slice(mOff, mOff + 32);
  mOff += 32;
  const { value: ixCount, length: ixCountLen } = shortVecDecode(messageBytes, mOff);
  mOff += ixCountLen;
  const instructions = [];
  for (let i = 0; i < ixCount; i++) {
    const programIdIndex = messageBytes[mOff++];
    const { value: accIdxCount, length: accIdxLen } = shortVecDecode(messageBytes, mOff);
    mOff += accIdxLen;
    const accIdxs = messageBytes.slice(mOff, mOff + accIdxCount);
    mOff += accIdxCount;
    const { value: dataLen, length: dataLenLen } = shortVecDecode(messageBytes, mOff);
    mOff += dataLenLen;
    const data = messageBytes.slice(mOff, mOff + dataLen);
    mOff += dataLen;
    instructions.push({ programIdIndex, accountKeyIndexes: Array.from(accIdxs), data: Array.from(data) });
  }
  return {
    version: isV0 ? 'v0' : 'legacy',
    sigCount,
    sigCountLen,
    signatures: signatures.map((s) => base58Encode(s)),
    messageOffset,
    numRequiredSignatures,
    numReadonlySignedAccounts,
    numReadonlyUnsignedAccounts,
    accountKeys: accountKeys.map((k) => base58Encode(k)),
    recentBlockhash: base58Encode(recentBlockhash),
    instructions: instructions.map((ix) => ({
      programId: base58Encode(accountKeys[ix.programIdIndex] || new Uint8Array(32)),
      accountKeyIndexes: ix.accountKeyIndexes,
      dataLen: ix.data.length
    }))
  };
}

/**
 * Sign a serialized transaction in place: parse, find our pubkey in
 * the required signer slots, ed25519-sign the message bytes, inject
 * our signature at the matching slot. Returns a new Uint8Array.
 */
function signTransactionInPlace(txBytes, seed, ourPubkeyBase58) {
  const parsed = parseTransaction(txBytes);
  const ourPubkey = base58Decode(ourPubkeyBase58);
  let ourIdx = -1;
  for (let i = 0; i < parsed.numRequiredSignatures; i++) {
    const k = base58Decode(parsed.accountKeys[i]);
    if (arrayEqual(k, ourPubkey)) { ourIdx = i; break; }
  }
  if (ourIdx === -1) throw mkErr('NOT_A_SIGNER', 'our pubkey is not a required signer of this transaction');

  const messageBytes = txBytes.slice(parsed.messageOffset);
  const sig = ed25519.sign(messageBytes, seed);

  const out = new Uint8Array(txBytes); // copy
  const sigStart = parsed.sigCountLen + ourIdx * 64;
  out.set(sig, sigStart);
  return out;
}

// ─── lifecycle ─────────────────────────────────────────────────────

chrome.runtime.onInstalled.addListener(() => {
  console.log('[spaniel-wallet] installed; vault locked.');
});

if (chrome?.idle?.onStateChanged?.addListener) {
  chrome.idle.setDetectionInterval?.(60);
  chrome.idle.onStateChanged.addListener((state) => {
    if (state === 'locked' && STATE.unlocked) lockNow();
  });
}

if (chrome?.tabs?.onRemoved?.addListener) {
  chrome.tabs.onRemoved.addListener((tabId) => {
    for (const [reqId, req] of [...STATE.pendingRequests]) {
      if (req.tabId === tabId) {
        try { req.reject(mkErr('TAB_CLOSED', 'origin tab closed')); } catch {}
        STATE.pendingRequests.delete(reqId);
      }
    }
  });
}

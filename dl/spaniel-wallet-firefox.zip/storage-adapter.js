// Spaniel Wallet — extension storage adapter.
//
// Implements the same { get, put, del, keys, clear } interface as
// js/wallet-core/storage.js's `indexedDbStorage`, backed by
// chrome.storage.local. The wallet-core does not need any change —
// the popup wires this adapter into `loadVaultEnvelope`, `loadMeta`,
// `saveVaultEnvelope`, `saveMeta`, `wipeWallet` the same way as the
// PWA wires its IndexedDB adapter.
//
// chrome.storage.local serializes values to a JSON-like form before
// write. Strings, numbers, arrays, plain objects work. Uint8Array
// does NOT survive a round trip — wallet-core stores vault envelopes
// as objects with `cipher`, `nonce`, `salt` arrays already, so this
// adapter only handles the simple case.

const browserStorage = (typeof browser !== 'undefined' && browser?.storage?.local)
  ? browser.storage.local
  : (typeof chrome !== 'undefined' && chrome?.storage?.local)
    ? chrome.storage.local
    : null;

if (!browserStorage) {
  // Loud failure — popup boot wraps this in a friendly error.
  throw new Error('chrome.storage.local is unavailable; extension permissions misconfigured.');
}

function wrapGet(key) {
  return new Promise((resolve, reject) => {
    try {
      const ret = browserStorage.get(key, (items) => {
        const err = (typeof chrome !== 'undefined' && chrome.runtime?.lastError)
          ? chrome.runtime.lastError
          : null;
        if (err) return reject(new Error(err.message || 'storage.get failed'));
        const v = items?.[key];
        resolve(v === undefined ? null : v);
      });
      // Firefox returns a promise instead of a callback.
      if (ret && typeof ret.then === 'function') {
        ret.then((items) => {
          const v = items?.[key];
          resolve(v === undefined ? null : v);
        }, reject);
      }
    } catch (e) {
      reject(e);
    }
  });
}

function wrapSet(obj) {
  return new Promise((resolve, reject) => {
    try {
      const ret = browserStorage.set(obj, () => {
        const err = (typeof chrome !== 'undefined' && chrome.runtime?.lastError)
          ? chrome.runtime.lastError
          : null;
        if (err) return reject(new Error(err.message || 'storage.set failed'));
        resolve();
      });
      if (ret && typeof ret.then === 'function') {
        ret.then(() => resolve(), reject);
      }
    } catch (e) {
      reject(e);
    }
  });
}

function wrapDel(key) {
  return new Promise((resolve, reject) => {
    try {
      const ret = browserStorage.remove(key, () => {
        const err = (typeof chrome !== 'undefined' && chrome.runtime?.lastError)
          ? chrome.runtime.lastError
          : null;
        if (err) return reject(new Error(err.message || 'storage.remove failed'));
        resolve();
      });
      if (ret && typeof ret.then === 'function') {
        ret.then(() => resolve(), reject);
      }
    } catch (e) {
      reject(e);
    }
  });
}

function wrapKeys() {
  return new Promise((resolve, reject) => {
    try {
      const ret = browserStorage.get(null, (items) => {
        const err = (typeof chrome !== 'undefined' && chrome.runtime?.lastError)
          ? chrome.runtime.lastError
          : null;
        if (err) return reject(new Error(err.message || 'storage.get(null) failed'));
        resolve(Object.keys(items || {}));
      });
      if (ret && typeof ret.then === 'function') {
        ret.then((items) => resolve(Object.keys(items || {})), reject);
      }
    } catch (e) {
      reject(e);
    }
  });
}

function wrapClear() {
  return new Promise((resolve, reject) => {
    try {
      const ret = browserStorage.clear(() => {
        const err = (typeof chrome !== 'undefined' && chrome.runtime?.lastError)
          ? chrome.runtime.lastError
          : null;
        if (err) return reject(new Error(err.message || 'storage.clear failed'));
        resolve();
      });
      if (ret && typeof ret.then === 'function') {
        ret.then(() => resolve(), reject);
      }
    } catch (e) {
      reject(e);
    }
  });
}

export function extensionStorage() {
  return {
    name: 'chrome.storage.local',
    async get(key) {
      return wrapGet(key);
    },
    async put(key, value) {
      await wrapSet({ [key]: value });
    },
    async del(key) {
      await wrapDel(key);
    },
    async keys() {
      return wrapKeys();
    },
    async clear() {
      await wrapClear();
    }
  };
}

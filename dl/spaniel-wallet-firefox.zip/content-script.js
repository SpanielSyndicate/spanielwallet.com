// Spaniel Wallet — extension content script (isolated world).
//
// Two responsibilities:
//   1. Inject `injected.js` into the main world so it can register a
//      Wallet Standard provider on `window.navigator.wallets`.
//   2. Bridge messages between the main-world provider (via
//      window.postMessage) and the background service worker (via
//      chrome.runtime.sendMessage).
//
// Wire protocol (all messages carry { source, target, kind, payload, id? }):
//
//   main-world → CS:    { source: 'spaniel-wallet:page', target: 'spaniel-wallet:ext', ... }
//   CS → main-world:    { source: 'spaniel-wallet:ext',  target: 'spaniel-wallet:page', ... }
//   CS → background:    { source: 'spaniel-wallet:cs',   kind, payload }
//   background → CS:    runtime response (resolves the sendMessage promise)

(function injectMainWorldProvider() {
  // The injected.js URL comes from web_accessible_resources in the
  // manifest. We use a <script> tag rather than <script type="module">
  // so the provider's globals are available immediately on the page
  // (no top-level await race with the dApp's wallet discovery code).
  try {
    const src = chrome.runtime.getURL('injected.js');
    const script = document.createElement('script');
    script.src = src;
    script.async = false;
    script.dataset.spanielWalletInject = '1';
    (document.head || document.documentElement).appendChild(script);
    script.addEventListener('load', () => {
      // The main-world provider has registered itself; clean up the
      // <script> tag so dApps don't see it lingering. Provider lifetime
      // is bound to the window, not this tag.
      script.remove();
    }, { once: true });
  } catch (e) {
    console.warn('[spaniel-wallet] inject failed', e);
  }
})();

window.addEventListener('message', (event) => {
  if (event.source !== window) return;
  const data = event.data;
  if (!data || typeof data !== 'object') return;
  if (data.source !== 'spaniel-wallet:page' || data.target !== 'spaniel-wallet:ext') return;
  const { id, kind, payload } = data;
  if (!id || !kind) return;

  chrome.runtime.sendMessage(
    { source: 'spaniel-wallet:cs', kind, payload },
    (res) => {
      const err = chrome.runtime?.lastError;
      const reply = {
        source: 'spaniel-wallet:ext',
        target: 'spaniel-wallet:page',
        id,
        ok: !err && !(res && res.error),
        result: (res && !res.error) ? res : null,
        error: err
          ? { code: 'BRIDGE', message: err.message || 'bridge failure' }
          : (res?.error || null)
      };
      window.postMessage(reply, window.location.origin);
    }
  );
});

// Spaniel Wallet — extension popup controller.
//
// Two distinct modes, decided by URL search params:
//   (a) "wallet" mode — no `?request=` param. Show vault state
//       (create/import landing → unlock → unlocked main).
//   (b) "approval" mode — `?request=<id>&kind=<kind>`. Show the
//       pending request from the background SW and Approve/Reject.
//
// All wallet-core primitives are imported from the bundled
// /js/wallet-core/ tree (no IndexedDB; the storage adapter writes
// to chrome.storage.local).

import {
  loadVaultEnvelope,
  loadMeta,
  saveVaultEnvelope,
  saveMeta,
  wipeWallet
} from './js/wallet-core/storage.js';
import {
  createVault,
  importVault,
  unlockVault
} from './js/wallet-core/vault.js';
import { shortPubkey } from './js/wallet-core/receive.js';
import { extensionStorage } from './storage-adapter.js';

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

const PARAMS = new URLSearchParams(location.search);
const REQUEST_ID = PARAMS.get('request');
const REQUEST_KIND = PARAMS.get('kind');

const storage = extensionStorage();
const main = $('#extMain');
const lockPill = $('#lockPill');

// ─── tiny IPC helpers ──────────────────────────────────────────────

function bgSend(kind, payload) {
  return new Promise((resolve, reject) => {
    try {
      chrome.runtime.sendMessage({ source: 'spaniel-wallet:popup', kind, payload }, (res) => {
        const err = chrome.runtime?.lastError;
        if (err) return reject(new Error(err.message || 'runtime error'));
        if (res?.error) return reject(Object.assign(new Error(res.error.message), { code: res.error.code }));
        resolve(res);
      });
    } catch (e) {
      reject(e);
    }
  });
}

function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[c]);
}

function setMain(html) {
  main.innerHTML = html;
}

function setError(msg) {
  setMain(`<div class="ext-error">${escapeHtml(msg)}</div>
    <button class="ext-btn" id="errReload">Reload</button>`);
  $('#errReload').addEventListener('click', () => location.reload());
}

function setBusy(msg) {
  setMain(`<div class="ext-loading">${escapeHtml(msg)}</div>`);
}

function setPill(state, text) {
  lockPill.dataset.state = state;
  lockPill.textContent = text;
}

// ─── State machine ────────────────────────────────────────────────

async function boot() {
  try {
    if (REQUEST_ID && REQUEST_KIND) {
      await mountApproval();
    } else {
      await mountWallet();
    }
  } catch (err) {
    console.error('[popup] boot failed', err);
    setError(`Spaniel Wallet failed to load: ${err.message || err}`);
  }

  // Listen for background broadcasts (state changes from other popups).
  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg || msg.source !== 'spaniel-wallet:bg') return;
    if (msg.type === 'state') {
      if (msg.unlocked) setPill('unlocked', `Unlocked · ${shortPubkey(msg.activePubkey)}`);
      else setPill('locked', 'Locked');
    }
  });

  $('#lockNowLink')?.addEventListener('click', async (ev) => {
    ev.preventDefault();
    try {
      await bgSend('lock');
      await mountWallet(); // refresh
    } catch (e) {
      console.warn('lock failed', e);
    }
  });
}

// ─── WALLET MODE ──────────────────────────────────────────────────

async function mountWallet() {
  setBusy('Checking vault…');
  let envelope = null;
  let meta = null;
  try {
    envelope = await loadVaultEnvelope(storage);
  } catch (e) {
    if (e?.code !== 'WALLET_VAULT_NOT_FOUND') throw e;
  }
  meta = await loadMeta(storage);

  if (!envelope) {
    setPill('missing', 'No wallet');
    renderNoVault();
    return;
  }

  // Vault exists — query bg for unlocked state.
  const state = await bgSend('getUnlockedState');
  if (state.unlocked && state.activePubkey) {
    setPill('unlocked', `Unlocked · ${shortPubkey(state.activePubkey)}`);
    renderUnlocked({ activePubkey: state.activePubkey, meta });
  } else {
    setPill('locked', 'Locked');
    renderUnlockPrompt({ envelope, meta });
  }
}

function renderNoVault() {
  setMain(`
    <div class="ext-landing-cta">
      <h2>Welcome to Spaniel Wallet</h2>
      <p style="color: var(--fg-2); margin: 8px 0;">
        A first-party, non-custodial Solana wallet. Create a fresh
        wallet or import an existing seed phrase.
      </p>
    </div>
    <div class="ext-section">
      <h2>Get started</h2>
      <div class="ext-btn-row">
        <button class="ext-btn ext-btn-primary" id="popupCreate">Create wallet</button>
        <button class="ext-btn" id="popupImport">Import seed phrase</button>
      </div>
      <p class="ext-hint" style="margin-top:10px;">
        Need more space? Open the
        <a href="https://spanielwallet.com" target="_blank" rel="noopener">full wallet at spanielwallet.com</a>
        to create, back up, and verify your seed with anti-shoulder-surfing reveal.
      </p>
    </div>
  `);
  $('#popupCreate').addEventListener('click', () => renderCreateFlow());
  $('#popupImport').addEventListener('click', () => renderImportFlow());
}

function renderCreateFlow() {
  setMain(`
    <div class="ext-section">
      <h2>Create a new wallet</h2>
      <div class="ext-warn">
        Use a strong passphrase. If you forget it your funds are
        unrecoverable. Back up your seed phrase from the
        <a href="https://spanielwallet.com/security/" target="_blank" rel="noopener">Security tab</a> after setup.
      </div>
      <div class="ext-field">
        <label>Passphrase</label>
        <input type="password" class="ext-input" id="newPass1" autocomplete="new-password" autofocus />
      </div>
      <div class="ext-field">
        <label>Confirm passphrase</label>
        <input type="password" class="ext-input" id="newPass2" autocomplete="new-password" />
      </div>
      <div class="ext-btn-row">
        <button class="ext-btn ext-btn-primary" id="doCreate">Create wallet</button>
        <button class="ext-btn" id="cancelCreate">Cancel</button>
      </div>
      <div id="createMsg"></div>
    </div>
  `);
  $('#cancelCreate').addEventListener('click', mountWallet);
  $('#doCreate').addEventListener('click', async () => {
    const p1 = $('#newPass1').value;
    const p2 = $('#newPass2').value;
    const msgEl = $('#createMsg');
    msgEl.innerHTML = '';
    if (!p1 || p1.length < 8) {
      msgEl.innerHTML = `<div class="ext-error">Passphrase must be at least 8 characters.</div>`;
      return;
    }
    if (p1 !== p2) {
      msgEl.innerHTML = `<div class="ext-error">Passphrases don't match.</div>`;
      return;
    }
    msgEl.innerHTML = `<div class="ext-loading">Generating mnemonic + encrypting…</div>`;
    try {
      const result = await createVault({ passphrase: p1, label: 'Account 1' });
      await saveVaultEnvelope(storage, result.envelope);
      const newMeta = {
        accounts: result.unlocked.accounts.map((a) => ({ pubkeyBase58: a.pubkeyBase58, label: a.label })),
        activePubkey: result.unlocked.activePubkey,
        createdAt: new Date().toISOString()
      };
      await saveMeta(storage, newMeta);
      // Pass the seed bytes to the background.
      await bgSend('setUnlocked', {
        activePubkey: result.unlocked.activePubkey,
        signers: result.unlocked.accounts.map((a) => ({
          pubkey: a.pubkeyBase58,
          seed: Array.from(a.seed)
        }))
      });
      msgEl.innerHTML = `
        <div class="ext-success">
          Wallet created. Your address:<br>
          <code style="word-break:break-all">${escapeHtml(result.unlocked.activePubkey)}</code>
        </div>
        <p class="ext-hint" style="margin-top:10px;">
          <strong>Back up your seed phrase NOW.</strong> Open
          <a href="https://spanielwallet.com/security/" target="_blank" rel="noopener">spanielwallet.com/security</a>
          to reveal and verify it. Without the seed, a forgotten
          passphrase means lost funds.
        </p>
      `;
      setTimeout(() => mountWallet(), 1800);
    } catch (err) {
      msgEl.innerHTML = `<div class="ext-error">Create failed: ${escapeHtml(err.message || err)}</div>`;
    }
  });
}

function renderImportFlow() {
  setMain(`
    <div class="ext-section">
      <h2>Import seed phrase</h2>
      <p style="color:var(--fg-2);">Paste a 12- or 24-word BIP-39 mnemonic. Spaces between words; case-insensitive.</p>
      <div class="ext-field">
        <label>Seed phrase</label>
        <textarea class="ext-textarea" id="importMnem" rows="3" autocapitalize="none" autocorrect="off" spellcheck="false"></textarea>
      </div>
      <div class="ext-field">
        <label>New passphrase (encrypts the seed at rest)</label>
        <input type="password" class="ext-input" id="importPass" autocomplete="new-password" />
      </div>
      <div class="ext-btn-row">
        <button class="ext-btn ext-btn-primary" id="doImport">Import</button>
        <button class="ext-btn" id="cancelImport">Cancel</button>
      </div>
      <div id="importMsg"></div>
    </div>
  `);
  $('#cancelImport').addEventListener('click', mountWallet);
  $('#doImport').addEventListener('click', async () => {
    const mnem = $('#importMnem').value.trim().replace(/\s+/g, ' ').toLowerCase();
    const pass = $('#importPass').value;
    const msgEl = $('#importMsg');
    msgEl.innerHTML = '';
    if (!mnem) {
      msgEl.innerHTML = `<div class="ext-error">Seed phrase is required.</div>`; return;
    }
    if (!pass || pass.length < 8) {
      msgEl.innerHTML = `<div class="ext-error">Passphrase must be at least 8 characters.</div>`; return;
    }
    msgEl.innerHTML = `<div class="ext-loading">Importing + encrypting…</div>`;
    try {
      const result = await importVault({ passphrase: pass, secret: mnem, label: 'Account 1' });
      await saveVaultEnvelope(storage, result.envelope);
      const newMeta = {
        accounts: result.unlocked.accounts.map((a) => ({ pubkeyBase58: a.pubkeyBase58, label: a.label })),
        activePubkey: result.unlocked.activePubkey,
        createdAt: new Date().toISOString()
      };
      await saveMeta(storage, newMeta);
      await bgSend('setUnlocked', {
        activePubkey: result.unlocked.activePubkey,
        signers: result.unlocked.accounts.map((a) => ({
          pubkey: a.pubkeyBase58,
          seed: Array.from(a.seed)
        }))
      });
      msgEl.innerHTML = `<div class="ext-success">Imported. Address: <code style="word-break:break-all">${escapeHtml(result.unlocked.activePubkey)}</code></div>`;
      setTimeout(() => mountWallet(), 1400);
    } catch (err) {
      msgEl.innerHTML = `<div class="ext-error">Import failed: ${escapeHtml(err.message || err)}</div>`;
    }
  });
}

function renderUnlockPrompt({ envelope, meta }) {
  setMain(`
    <div class="ext-section">
      <h2>Unlock wallet</h2>
      <p style="color:var(--fg-2);">
        Account: <code>${escapeHtml(meta?.activePubkey ? shortPubkey(meta.activePubkey) : '—')}</code>
      </p>
      <div class="ext-field">
        <label>Passphrase</label>
        <input type="password" class="ext-input" id="unlockPass" autofocus autocomplete="current-password" />
      </div>
      <div class="ext-btn-row">
        <button class="ext-btn ext-btn-primary" id="doUnlock">Unlock</button>
      </div>
      <div id="unlockMsg"></div>
    </div>
    <details class="ext-section">
      <summary style="cursor:pointer;color:var(--fg-2);">Wipe this wallet</summary>
      <p style="color:var(--fg-3);font-size:12px;margin-top:6px;">
        Removes the encrypted vault from this browser. Has no effect on funds — your seed phrase is still the source of truth. Type DELETE to confirm.
      </p>
      <input class="ext-input" id="wipeConfirm" placeholder='Type "DELETE" to confirm' />
      <button class="ext-btn ext-btn-danger" id="doWipe" style="margin-top:6px;">Wipe wallet</button>
    </details>
  `);
  $('#unlockPass').addEventListener('keyup', (ev) => { if (ev.key === 'Enter') $('#doUnlock').click(); });
  $('#doUnlock').addEventListener('click', async () => {
    const pass = $('#unlockPass').value;
    const msgEl = $('#unlockMsg');
    msgEl.innerHTML = `<div class="ext-loading">Unlocking…</div>`;
    try {
      const unlocked = await unlockVault({ envelope, passphrase: pass });
      await bgSend('setUnlocked', {
        activePubkey: unlocked.activePubkey,
        signers: unlocked.accounts.map((a) => ({
          pubkey: a.pubkeyBase58,
          seed: Array.from(a.seed)
        }))
      });
      msgEl.innerHTML = `<div class="ext-success">Unlocked.</div>`;
      setTimeout(mountWallet, 600);
    } catch (err) {
      msgEl.innerHTML = `<div class="ext-error">Couldn't unlock: ${escapeHtml(err.message || err)}</div>`;
    }
  });
  $('#doWipe').addEventListener('click', async () => {
    if ($('#wipeConfirm').value.trim() !== 'DELETE') return;
    await wipeWallet(storage);
    await bgSend('lock');
    mountWallet();
  });
}

function renderUnlocked({ activePubkey }) {
  setMain(`
    <div class="ext-section">
      <h2>Account</h2>
      <div class="ext-address" id="addrField">${escapeHtml(activePubkey)}</div>
      <div class="ext-btn-row">
        <button class="ext-btn" id="copyAddr">Copy address</button>
        <button class="ext-btn ext-btn-danger" id="lockNow">Lock</button>
      </div>
    </div>
    <div class="ext-section">
      <h2>Connected dApps</h2>
      <div id="connList" class="ext-hint">Loading…</div>
    </div>
    <div class="ext-section">
      <h2>Need full features?</h2>
      <p style="color:var(--fg-2);">Send SOL, view your binder, manage Rescue votes, and back up your seed in the full wallet.</p>
      <a class="ext-btn ext-btn-primary" href="https://spanielwallet.com" target="_blank" rel="noopener" style="display:inline-block;text-decoration:none;text-align:center;">
        Open full wallet ↗
      </a>
    </div>
  `);
  $('#copyAddr').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(activePubkey); $('#copyAddr').textContent = 'Copied!'; setTimeout(() => $('#copyAddr').textContent = 'Copy address', 1200); } catch {}
  });
  $('#lockNow').addEventListener('click', async () => {
    await bgSend('lock');
    mountWallet();
  });
  // populate connections
  bgSend('getConnections').then((r) => {
    const list = r?.connections || [];
    const el = $('#connList');
    if (!el) return;
    if (list.length === 0) {
      el.innerHTML = '<div style="color:var(--fg-3)">No dApps connected.</div>';
    } else {
      el.innerHTML = list.map((c) => `
        <div style="font-family:var(--mono);font-size:12px;padding:6px 0;border-bottom:1px solid var(--border)">
          ${escapeHtml(c.origin)}
        </div>
      `).join('');
    }
  });
}

// ─── APPROVAL MODE ────────────────────────────────────────────────

async function mountApproval() {
  setBusy('Loading request…');
  // Make sure wallet is unlocked first — if locked, we redirect to
  // unlock flow but keep the request id in the URL so we can come
  // back. Connect requests require approval BEFORE unlock would
  // be useful — for sign* we definitely need unlock.
  const state = await bgSend('getUnlockedState');
  let req;
  try {
    req = await bgSend('getPendingRequest', { requestId: REQUEST_ID });
  } catch (err) {
    setError(`Couldn't load request: ${err.message || err}`);
    return;
  }
  if (req?.error) {
    setError(req.error.message || 'Request not found.');
    return;
  }

  if (!state.unlocked && REQUEST_KIND !== 'connect') {
    // Need to unlock first.
    setPill('locked', 'Locked');
    renderUnlockForApproval(req);
    return;
  }

  if (state.unlocked) {
    setPill('unlocked', `Unlocked · ${shortPubkey(state.activePubkey)}`);
  } else {
    setPill('missing', 'No wallet');
  }

  switch (REQUEST_KIND) {
    case 'connect':       return renderConnectApproval(req, state);
    case 'signMessage':   return renderSignMessageApproval(req);
    case 'signTransaction': return renderSignTransactionApproval(req);
    default:              return setError(`Unsupported request kind: ${REQUEST_KIND}`);
  }
}

function renderUnlockForApproval(req) {
  setMain(`
    <div class="ext-section">
      <h2>Unlock to continue</h2>
      <div class="ext-approval-origin">${escapeHtml(req.origin)}</div>
      <p style="color:var(--fg-2);">This dApp is requesting to <strong>${escapeHtml(req.kind)}</strong>. Unlock your wallet to review.</p>
      <div class="ext-field">
        <label>Passphrase</label>
        <input type="password" class="ext-input" id="unlockPass" autofocus />
      </div>
      <div class="ext-btn-row">
        <button class="ext-btn ext-btn-primary" id="doUnlock">Unlock & review</button>
        <button class="ext-btn ext-btn-danger" id="rejectReq">Reject</button>
      </div>
      <div id="unlockMsg"></div>
    </div>
  `);
  $('#unlockPass').addEventListener('keyup', (ev) => { if (ev.key === 'Enter') $('#doUnlock').click(); });
  $('#doUnlock').addEventListener('click', async () => {
    const pass = $('#unlockPass').value;
    const msgEl = $('#unlockMsg');
    msgEl.innerHTML = `<div class="ext-loading">Unlocking…</div>`;
    try {
      const envelope = await loadVaultEnvelope(storage);
      const unlocked = await unlockVault({ envelope, passphrase: pass });
      await bgSend('setUnlocked', {
        activePubkey: unlocked.activePubkey,
        signers: unlocked.accounts.map((a) => ({
          pubkey: a.pubkeyBase58,
          seed: Array.from(a.seed)
        }))
      });
      mountApproval();
    } catch (err) {
      msgEl.innerHTML = `<div class="ext-error">${escapeHtml(err.message || err)}</div>`;
    }
  });
  $('#rejectReq').addEventListener('click', async () => {
    await bgSend('rejectRequest', { requestId: REQUEST_ID }).catch(() => {});
    window.close();
  });
}

function renderConnectApproval(req, state) {
  if (!state.unlocked) {
    return renderUnlockForApproval(req);
  }
  setMain(`
    <div class="ext-section">
      <h2>Connection request</h2>
      <div class="ext-approval-origin">${escapeHtml(req.origin)}</div>
      <p style="color:var(--fg-2);">This dApp wants to view your public address and request signatures from you.</p>
      <p style="color:var(--fg-2);font-family:var(--mono);font-size:13px;">
        Account: <strong>${escapeHtml(state.activePubkey ? shortPubkey(state.activePubkey) : '—')}</strong>
      </p>
      <div class="ext-btn-row">
        <button class="ext-btn ext-btn-primary" id="doApprove">Connect</button>
        <button class="ext-btn ext-btn-danger" id="doReject">Reject</button>
      </div>
      <p class="ext-hint">
        Connecting only shares your public address. Signing
        transactions still requires explicit approval here.
      </p>
    </div>
  `);
  $('#doApprove').addEventListener('click', async () => {
    try {
      await bgSend('approveConnect', { requestId: REQUEST_ID });
      window.close();
    } catch (err) { setError(`Approve failed: ${err.message || err}`); }
  });
  $('#doReject').addEventListener('click', async () => {
    await bgSend('rejectRequest', { requestId: REQUEST_ID }).catch(() => {});
    window.close();
  });
}

function renderSignMessageApproval(req) {
  const msgBytes = req.payload?.message || [];
  let display;
  try {
    display = new TextDecoder('utf-8', { fatal: true }).decode(Uint8Array.from(msgBytes));
  } catch {
    display = `<binary: ${msgBytes.length} bytes>`;
  }
  setMain(`
    <div class="ext-section">
      <h2>Sign message</h2>
      <div class="ext-approval-origin">${escapeHtml(req.origin)}</div>
      <p style="color:var(--fg-2);">This dApp wants you to sign the following message:</p>
      <div class="ext-payload-view">${escapeHtml(display)}</div>
      <div class="ext-btn-row">
        <button class="ext-btn ext-btn-primary" id="doApprove">Sign message</button>
        <button class="ext-btn ext-btn-danger" id="doReject">Reject</button>
      </div>
      <p class="ext-hint">
        Signing this message does not move funds. The signature
        proves ownership of your wallet's address.
      </p>
    </div>
  `);
  $('#doApprove').addEventListener('click', async () => {
    try {
      await bgSend('approveSignMessage', { requestId: REQUEST_ID });
      window.close();
    } catch (err) { setError(`Sign failed: ${err.message || err}`); }
  });
  $('#doReject').addEventListener('click', async () => {
    await bgSend('rejectRequest', { requestId: REQUEST_ID }).catch(() => {});
    window.close();
  });
}

async function renderSignTransactionApproval(req) {
  let preview = null;
  try {
    const r = await bgSend('previewSignTransaction', { transaction: req.payload?.transaction || [] });
    preview = r?.preview;
  } catch {}
  const summary = preview
    ? `
      <div class="ext-payload-view">
Version:                ${preview.version}
Signers required:       ${preview.numRequiredSignatures}
Accounts referenced:    ${preview.accountKeys.length}
Instructions:           ${preview.instructions.length}
Recent blockhash:       ${preview.recentBlockhash}

Programs invoked:
${preview.instructions.map((ix, i) => `  ${i + 1}. ${ix.programId}  · ${ix.accountKeyIndexes.length} accounts · ${ix.dataLen} bytes data`).join('\n')}
      </div>
    `
    : `<div class="ext-error">Couldn't parse transaction — refusing to sign blindly.</div>`;
  setMain(`
    <div class="ext-section">
      <h2>Sign transaction</h2>
      <div class="ext-approval-origin">${escapeHtml(req.origin)}</div>
      <p style="color:var(--fg-2);">Review the transaction details below before signing.</p>
      ${summary}
      <div class="ext-btn-row" style="margin-top:10px;">
        <button class="ext-btn ext-btn-primary" id="doApprove" ${preview ? '' : 'disabled'}>Sign transaction</button>
        <button class="ext-btn ext-btn-danger" id="doReject">Reject</button>
      </div>
      <p class="ext-hint">
        Signing broadcasts the transaction via the dApp's RPC. The
        wallet does not send it itself.
      </p>
    </div>
  `);
  $('#doApprove').addEventListener('click', async () => {
    try {
      await bgSend('approveSignTransaction', { requestId: REQUEST_ID });
      window.close();
    } catch (err) { setError(`Sign failed: ${err.message || err}`); }
  });
  $('#doReject').addEventListener('click', async () => {
    await bgSend('rejectRequest', { requestId: REQUEST_ID }).catch(() => {});
    window.close();
  });
}

boot();

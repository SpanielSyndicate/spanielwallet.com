// Spaniel Wallet — main-world Wallet Standard provider.
//
// Runs in the dApp page's main JavaScript world. Registers a Wallet
// Standard provider by dispatching a `wallet-standard:register-wallet`
// CustomEvent that the Wallet Standard app library listens for. Modern
// Solana dApps using `@solana/wallet-standard-features` see Spaniel
// Wallet appear in their adapter list.
//
// All signing / connecting actions are forwarded to the background
// service worker via the content script bridge:
//
//     injected.js  --postMessage-->  content-script.js  --sendMessage-->  background.js
//
// We never touch private keys here.

(function spanielWalletProvider() {
  if (window.spanielWallet) return; // already injected

  const ICON_DATA_URL = "data:image/svg+xml;utf8," + encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">' +
      '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">' +
      '<stop offset="0" stop-color="#f0a52b"/>' +
      '<stop offset="1" stop-color="#a85a06"/></linearGradient></defs>' +
      '<rect width="64" height="64" rx="14" fill="#08070a"/>' +
      '<path fill="url(#g)" d="M20 20q6-7 12-7t12 7q5 6 5 14 0 9-7 14-3 2-7 2h-6q-4 0-7-2-7-5-7-14 0-8 5-14z"/>' +
      '<circle cx="26" cy="29" r="2.6" fill="#08070a"/>' +
      '<circle cx="38" cy="29" r="2.6" fill="#08070a"/>' +
      '<path fill="#08070a" d="M30 38q2 3 4 0z"/>' +
    '</svg>'
  );

  const CHAINS = Object.freeze(['solana:mainnet', 'solana:devnet', 'solana:testnet']);
  const PROVIDER_VERSION = '1.0.0';

  const pending = new Map(); // id → { resolve, reject }
  let nextRequestId = 1;

  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== 'spaniel-wallet:ext' || data.target !== 'spaniel-wallet:page') return;
    const entry = pending.get(data.id);
    if (!entry) return;
    pending.delete(data.id);
    if (data.ok) entry.resolve(data.result || {});
    else entry.reject(Object.assign(new Error(data.error?.message || 'request failed'), { code: data.error?.code }));
  });

  function request(kind, payload) {
    const id = `pg-${nextRequestId++}-${Date.now()}`;
    return new Promise((resolve, reject) => {
      pending.set(id, { resolve, reject });
      window.postMessage({
        source: 'spaniel-wallet:page',
        target: 'spaniel-wallet:ext',
        id,
        kind,
        payload: payload || {}
      }, window.location.origin);
    });
  }

  // ─── Wallet account ───────────────────────────────────────────────

  function makeAccount(pubkeyBase58) {
    const addressBytes = base58Decode(pubkeyBase58);
    return Object.freeze({
      address: pubkeyBase58,
      publicKey: addressBytes,
      chains: CHAINS,
      features: Object.freeze([
        'solana:signMessage',
        'solana:signTransaction',
        'solana:signAndSendTransaction'
      ]),
      label: 'Spaniel Wallet'
    });
  }

  const state = {
    accounts: [],
    listeners: new Set()
  };

  function emitChange(properties) {
    for (const cb of state.listeners) {
      try { cb(properties); } catch (e) { console.warn('[spaniel-wallet] listener error', e); }
    }
  }

  // ─── Feature implementations ──────────────────────────────────────

  async function standardConnect({ silent } = {}) {
    if (silent && state.accounts.length > 0) return { accounts: state.accounts };
    if (silent) {
      // Probe the background for an existing connection on this origin.
      const c = await request('getConnection');
      if (c?.connected && c.pubkey) {
        state.accounts = [makeAccount(c.pubkey)];
        emitChange({ accounts: state.accounts });
        return { accounts: state.accounts };
      }
      return { accounts: [] };
    }
    const res = await request('connect', {});
    if (!res?.pubkey) throw new Error('connect: no pubkey returned');
    state.accounts = [makeAccount(res.pubkey)];
    emitChange({ accounts: state.accounts });
    return { accounts: state.accounts };
  }

  async function standardDisconnect() {
    await request('disconnect');
    state.accounts = [];
    emitChange({ accounts: state.accounts });
  }

  function standardEventsOn(event, listener) {
    if (event !== 'change') return () => {};
    state.listeners.add(listener);
    return () => state.listeners.delete(listener);
  }

  async function solanaSignMessage(...inputs) {
    // Flatten — the wallet-standard feature is called with an array of
    // { account, message } objects; dApps usually pass one.
    const flat = inputs.flat();
    const outputs = [];
    for (const input of flat) {
      const msg = input.message instanceof Uint8Array ? input.message : new Uint8Array(input.message || []);
      const res = await request('signMessage', {
        accountAddress: input.account?.address || (state.accounts[0]?.address ?? null),
        message: Array.from(msg)
      });
      if (!res?.signature) throw new Error('signMessage: no signature returned');
      const sig = Uint8Array.from(res.signature);
      outputs.push({ signedMessage: msg, signature: sig });
    }
    return outputs;
  }

  async function solanaSignTransaction(...inputs) {
    const flat = inputs.flat();
    const outputs = [];
    for (const input of flat) {
      const tx = input.transaction instanceof Uint8Array ? input.transaction : new Uint8Array(input.transaction || []);
      const res = await request('signTransaction', {
        accountAddress: input.account?.address || (state.accounts[0]?.address ?? null),
        chain: input.chain || 'solana:mainnet',
        transaction: Array.from(tx)
      });
      if (!res?.signedTransaction) throw new Error('signTransaction: no signed transaction returned');
      outputs.push({ signedTransaction: Uint8Array.from(res.signedTransaction) });
    }
    return outputs;
  }

  async function solanaSignAndSendTransaction(...inputs) {
    const flat = inputs.flat();
    const outputs = [];
    for (const input of flat) {
      const tx = input.transaction instanceof Uint8Array ? input.transaction : new Uint8Array(input.transaction || []);
      const res = await request('signAndSendTransaction', {
        accountAddress: input.account?.address || (state.accounts[0]?.address ?? null),
        chain: input.chain || 'solana:mainnet',
        transaction: Array.from(tx),
        options: input.options || null
      });
      if (!res?.signature) throw new Error('signAndSendTransaction: no signature returned');
      outputs.push({ signature: Uint8Array.from(res.signature) });
    }
    return outputs;
  }

  // ─── Wallet Standard wallet object ───────────────────────────────

  const wallet = Object.freeze({
    version: '1.0.0',
    name: 'Spaniel Wallet',
    icon: ICON_DATA_URL,
    chains: CHAINS,
    get accounts() { return state.accounts.slice(); },
    features: Object.freeze({
      'standard:connect': Object.freeze({
        version: '1.0.0',
        connect: standardConnect
      }),
      'standard:disconnect': Object.freeze({
        version: '1.0.0',
        disconnect: standardDisconnect
      }),
      'standard:events': Object.freeze({
        version: '1.0.0',
        on: standardEventsOn
      }),
      'solana:signMessage': Object.freeze({
        version: '1.1.0',
        signMessage: solanaSignMessage
      }),
      'solana:signTransaction': Object.freeze({
        version: '1.0.0',
        supportedTransactionVersions: ['legacy', 0],
        signTransaction: solanaSignTransaction
      }),
      'solana:signAndSendTransaction': Object.freeze({
        version: '1.0.0',
        supportedTransactionVersions: ['legacy', 0],
        signAndSendTransaction: solanaSignAndSendTransaction
      })
    })
  });

  // Wallet Standard registration: emit a `wallet-standard:register-wallet`
  // CustomEvent (per the spec) and also push to navigator.wallets for
  // older app code that still polls there.
  function register() {
    const callback = ({ register: appRegister }) => {
      try { appRegister(wallet); } catch (e) { console.warn('[spaniel-wallet] register error', e); }
    };
    try {
      const evt = new CustomEvent('wallet-standard:register-wallet', {
        detail: callback,
        bubbles: false
      });
      // Use plain dispatchEvent — the wallet-standard app listens on
      // window for this synchronously when it boots.
      window.dispatchEvent(evt);
    } catch (e) {
      console.warn('[spaniel-wallet] dispatch register-wallet failed', e);
    }
    try {
      const nav = window.navigator;
      const cur = Array.isArray(nav.wallets) ? nav.wallets : [];
      if (typeof cur.push === 'function') {
        cur.push(callback);
        // If the property is the frozen Wallet Standard shape, calling
        // push() on it triggers immediate registration.
        nav.wallets = cur;
      }
    } catch (e) {
      // non-fatal — Wallet Standard apps with the modern event API are
      // already registered via the CustomEvent above.
    }
  }

  register();
  // Also re-register on `wallet-standard:app-ready` — late-loading
  // dApps that initialize their wallet adapter after our content
  // script fires can pick us up this way.
  window.addEventListener('wallet-standard:app-ready', register);

  // Optional convenience: expose Spaniel-only handle on window so
  // non-Wallet-Standard dApps can detect us.
  Object.defineProperty(window, 'spanielWallet', {
    value: Object.freeze({
      isSpanielWallet: true,
      version: PROVIDER_VERSION,
      connect: () => standardConnect({ silent: false }),
      disconnect: standardDisconnect,
      signMessage: (msg) => solanaSignMessage({ message: msg }).then((r) => r[0].signature),
      signTransaction: (tx) => solanaSignTransaction({ transaction: tx }).then((r) => r[0].signedTransaction)
    }),
    writable: false,
    configurable: false
  });

  // ─── Tiny base58 decoder (only needs to handle valid pubkeys) ────

  function base58Decode(s) {
    const ALPHABET = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
    const MAP = (function () {
      const m = new Int8Array(128).fill(-1);
      for (let i = 0; i < ALPHABET.length; i++) m[ALPHABET.charCodeAt(i)] = i;
      return m;
    })();
    if (!s) return new Uint8Array(0);
    let zeros = 0;
    while (zeros < s.length && s[zeros] === '1') zeros++;
    let n = 0n;
    for (let i = 0; i < s.length; i++) {
      const c = s.charCodeAt(i);
      const d = c < 128 ? MAP[c] : -1;
      if (d < 0) throw new Error('invalid base58 character');
      n = n * 58n + BigInt(d);
    }
    const bytes = [];
    while (n > 0n) {
      bytes.push(Number(n & 0xffn));
      n >>= 8n;
    }
    bytes.reverse();
    const out = new Uint8Array(zeros + bytes.length);
    for (let i = 0; i < bytes.length; i++) out[zeros + i] = bytes[i];
    return out;
  }
})();
